const $=s=>document.querySelector(s), $$=s=>document.querySelectorAll(s);
const messages=$('#messages'), promptBox=$('#prompt');
let history=JSON.parse(localStorage.getItem('superai_history')||'[]');
const copy={en:{welcome:'What can I help you with?',placeholder:'Message SUPER AI...',you:'You',reply:'SUPER AI is ready as a prototype. To generate real answers, the next step is connecting a secure AI service. Your message was saved locally on this device.'},bn:{welcome:'আমি আপনাকে কীভাবে সাহায্য করতে পারি?',placeholder:'SUPER AI-কে লিখুন...',you:'আপনি',reply:'SUPER AI-এর প্রোটোটাইপ প্রস্তুত। সত্যিকারের AI উত্তর পেতে নিরাপদ AI সার্ভিস সংযোগ করতে হবে। আপনার বার্তাটি এই ডিভাইসে সংরক্ষিত হয়েছে।'},ms:{welcome:'Apa yang boleh saya bantu?',placeholder:'Mesej SUPER AI...',you:'Anda',reply:'Prototaip SUPER AI sedia. Untuk jawapan AI sebenar, sambungkan perkhidmatan AI yang selamat. Mesej anda disimpan pada peranti ini.'},ar:{welcome:'كيف يمكنني مساعدتك؟',placeholder:'اكتب إلى SUPER AI...',you:'أنت',reply:'النموذج الأولي لـ SUPER AI جاهز. للحصول على إجابات حقيقية، يجب ربط خدمة ذكاء اصطناعي آمنة.'},hi:{welcome:'मैं आपकी क्या मदद कर सकता हूँ?',placeholder:'SUPER AI को संदेश दें...',you:'आप',reply:'SUPER AI प्रोटोटाइप तैयार है। वास्तविक AI उत्तरों के लिए सुरक्षित AI सेवा जोड़नी होगी।'},es:{welcome:'¿En qué puedo ayudarte?',placeholder:'Escribe a SUPER AI...',you:'Tú',reply:'El prototipo de SUPER AI está listo. Para obtener respuestas reales, conecta un servicio de IA seguro.'}};
function lang(){return $('#language').value}
function setLang(v){$('#language').value=v;$('#language2').value=v;$('#welcomeTitle').textContent=copy[v].welcome;promptBox.placeholder=copy[v].placeholder;document.documentElement.dir=v==='ar'?'rtl':'ltr'}
$('#language').onchange=e=>setLang(e.target.value);$('#language2').onchange=e=>setLang(e.target.value);
function addMessage(text,who){let el=document.createElement('div');el.className='message '+who;el.textContent=text;messages.append(el);messages.scrollTop=messages.scrollHeight}
function save(){localStorage.setItem('superai_history',JSON.stringify(history));renderHistory()}
function send(text){text=(text||promptBox.value).trim();if(!text)return;addMessage(text,'user');promptBox.value='';const answer=copy[lang()].reply;addMessage(answer,'assistant');history.unshift({text,at:new Date().toLocaleString()});history=history.slice(0,30);save()}
$('#chatForm').addEventListener('submit',e=>{e.preventDefault();send()});
promptBox.addEventListener('keydown',e=>{if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();send()}});
$$('.suggestion').forEach(b=>b.onclick=()=>send(b.dataset.prompt));
$('#newChat').onclick=()=>{messages.innerHTML='';showPage('chat');$('#sidebar').classList.remove('open')};
function showPage(name){$$('.page').forEach(p=>p.classList.toggle('active',p.id==='page-'+name));$$('.nav').forEach(n=>n.classList.toggle('active',n.dataset.page===name));$('#sidebar').classList.remove('open')}
$$('.nav').forEach(n=>n.onclick=()=>showPage(n.dataset.page));
$$('.tool-card').forEach(b=>b.onclick=()=>{showPage('chat');promptBox.value='Help me with: '+b.dataset.tool;promptBox.focus()});
$('#menuBtn').onclick=()=>$('#sidebar').classList.toggle('open');
function renderHistory(){let box=$('#historyList');box.innerHTML='';if(!history.length){box.innerHTML='<p class="empty">No saved conversations yet.</p>';return}history.forEach(item=>{let el=document.createElement('div');el.className='history-item';let title=document.createElement('b');title.textContent=item.text;let date=document.createElement('small');date.textContent='  ·  '+item.at;date.style.color='var(--muted)';el.append(title,date);box.append(el)})}
$('#clearHistory').onclick=()=>{if(confirm('Clear all local chat history?')){history=[];save();messages.innerHTML=''}};
renderHistory();setLang('en');
if('serviceWorker'in navigator&&location.protocol.startsWith('http'))navigator.serviceWorker.register('./sw.js').catch(()=>{});
