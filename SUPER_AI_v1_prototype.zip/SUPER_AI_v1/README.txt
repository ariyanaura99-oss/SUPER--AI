SUPER AI — Version 1.0 prototype

Included:
- Mobile-first responsive web app
- Chat interface and local chat history
- Language selector: English, বাংলা, Bahasa Melayu, العربية, हिन्दी, Español
- AI tools navigation
- Admin panel preview
- PWA manifest and offline cache

IMPORTANT:
This is a working front-end prototype, not a fully connected AI service.
Real AI replies require a secure backend/API integration. Do not put private API keys
inside app.js or any browser-side file. Admin authentication, cloud sync, payments,
abuse prevention and app-store packaging are not implemented yet.

Run:
1. Unzip this folder.
2. Open index.html in a browser for basic use.
3. For install/offline PWA features, host the folder on an HTTPS static host.
